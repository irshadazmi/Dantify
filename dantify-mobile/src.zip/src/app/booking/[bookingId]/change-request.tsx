import React, { useState } from 'react';
import {
  ActivityIndicator, Pressable, ScrollView, Text, TextInput, View
} from 'react-native';

import { showAppDialog } from "@/components/ui/app-dialog";
import { useLocalSearchParams, useRouter } from 'expo-router';

import { useAppColors } from '@/hooks/use-app-colors';
import { bookingService } from '@/services/booking-service';
import type { BookingChangeRequestType } from '@/types/booking';

const first = (value?: string | string[]) =>
  Array.isArray(value) ? value[0] ?? '' : value ?? '';

export default function BookingChangeRequestScreen() {
  const colors = useAppColors();
  const router = useRouter();
  const params = useLocalSearchParams<{ bookingId?: string | string[] }>();
  const bookingId = Number(first(params.bookingId));

  const [requestType, setRequestType] = useState<BookingChangeRequestType>('CANCELLATION');
  const [reason, setReason] = useState('');
  const [requestedDate, setRequestedDate] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const fieldStyle = {
    borderWidth: 1, borderColor: colors.border, borderRadius: 9,
    paddingHorizontal: 12, paddingVertical: 12, color: colors.text,
    backgroundColor: colors.surface, marginTop: 7,
  } as const;

  const submit = async () => {
    if (!Number.isInteger(bookingId) || bookingId <= 0) {
      showAppDialog('Invalid booking', 'The booking reference is invalid.');
      return;
    }
    if (!reason.trim()) {
      showAppDialog('Reason required', 'Please enter a reason for your request.');
      return;
    }
    if (requestType === 'RESCHEDULE' && !/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}(:\d{2})?$/.test(requestedDate.trim())) {
      showAppDialog('Date and time required', 'Enter the requested date and time as YYYY-MM-DD HH:mm:ss.');
      return;
    }

    try {
      setSubmitting(true);
      await bookingService.createChangeRequest(bookingId, {
        request_type: requestType,
        reason: reason.trim(),
        ...(requestType === 'RESCHEDULE' ? { requested_booking_date: requestedDate.trim() } : {}),
      });
      showAppDialog(
        'Request submitted',
        'Your request has been sent to the clinic for review.',
        [{ text: 'OK', onPress: () => router.replace({
          pathname: '/booking/[bookingId]',
          params: { bookingId: String(bookingId) },
        } as never) }],
      );
    } catch (err) {
      const message =
        typeof err === 'object' && err !== null && 'response' in err
          ? (err as { response?: { data?: { message?: string; errors?: Record<string, string[]> } } }).response?.data?.message
          : undefined;
      showAppDialog('Unable to submit request', message || 'Please check your details and try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <ScrollView style={{ flex: 1, backgroundColor: colors.background }}
      contentContainerStyle={{ padding: 16, paddingBottom: 32 }}>
      <Pressable onPress={() => router.back()}>
        <Text style={{ color: colors.primary, fontWeight: '700' }}>‹ Back to Booking</Text>
      </Pressable>

      <Text style={{ color: colors.text, fontSize: 22, fontWeight: '800', marginTop: 18 }}>
        Change Appointment
      </Text>
      <Text style={{ color: colors.textMuted, fontSize: 13, lineHeight: 19, marginTop: 6 }}>
        Booking #{bookingId}. Your request will be reviewed by the clinic. Your appointment is not changed until the clinic approves it.
      </Text>

      <View style={{ backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1, borderRadius: 12, padding: 15, marginTop: 18 }}>
        <Text style={{ color: colors.text, fontWeight: '800', marginBottom: 10 }}>Request type</Text>
        {([
          ['CANCELLATION', 'Request cancellation'],
          ['RESCHEDULE', 'Request rescheduling'],
        ] as const).map(([value, label]) => {
          const selected = requestType === value;
          return <Pressable key={value} onPress={() => setRequestType(value)}
            style={{ flexDirection: 'row', alignItems: 'center', paddingVertical: 11 }}>
            <View style={{ width: 19, height: 19, borderRadius: 10, borderWidth: 2,
              borderColor: selected ? colors.primary : colors.border, alignItems: 'center', justifyContent: 'center' }}>
              {selected && <View style={{ width: 9, height: 9, borderRadius: 5, backgroundColor: colors.primary }} />}
            </View>
            <Text style={{ color: colors.text, marginLeft: 10, fontWeight: selected ? '800' : '500' }}>{label}</Text>
          </Pressable>;
        })}

        {requestType === 'RESCHEDULE' && <>
          <Text style={{ color: colors.text, fontWeight: '700', marginTop: 13 }}>Requested date and time</Text>
          <TextInput value={requestedDate} onChangeText={setRequestedDate}
            placeholder="2026-11-12 11:30:00" placeholderTextColor={colors.textMuted}
            style={fieldStyle} autoCapitalize="none" />
          <Text style={{ color: colors.textMuted, fontSize: 11, marginTop: 5 }}>
            Format: YYYY-MM-DD HH:mm:ss. The clinic will recheck slot availability before approval.
          </Text>
        </>}

        <Text style={{ color: colors.text, fontWeight: '700', marginTop: 17 }}>Reason</Text>
        <TextInput value={reason} onChangeText={setReason}
          placeholder="Explain why you need this change..."
          placeholderTextColor={colors.textMuted}
          style={[fieldStyle, { minHeight: 110, textAlignVertical: 'top' }]}
          multiline maxLength={2000} />
      </View>

      <Pressable onPress={() => void submit()} disabled={submitting}
        style={{ backgroundColor: colors.primary, borderRadius: 10, padding: 15,
          alignItems: 'center', marginTop: 18, opacity: submitting ? 0.6 : 1 }}>
        {submitting ? <ActivityIndicator color={colors.textInverse} /> :
          <Text style={{ color: colors.textInverse, fontWeight: '800' }}>Submit Request</Text>}
      </Pressable>
    </ScrollView>
  );
}
