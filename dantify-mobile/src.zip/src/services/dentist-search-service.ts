import api from '@/config/api';

import type {
  ApiResponse,
  PaginatedResponse,
  PaginationParams,
} from '@/types/api';

import type { Address } from '@/types/address';

/* ======================================================
   PUBLIC SEARCH TYPES
====================================================== */

export interface PublicSearchClinic {
  id: number;
  name: string;
  address: string | null;
  city: string | null;
  state: string | null;
  country: string | null;
  postal_code: string | null;
  phone: string | null;
  email: string | null;
  profile_photo_url: string | null;
}

export interface PublicSearchDentist {
  id: number;
  user_id: number;
  name: string;
  specialization?: string | null;
  gender?: string | null;
  phone?: string | null;
  email?: string | null;
  profile_photo_url: string | null;
  clinics: PublicSearchClinic[];
}

export interface DentistSearchParams extends PaginationParams {
  query?: string;
  location?: string;
}

export type DentistSearchResponse =
  ApiResponse<PaginatedResponse<PublicSearchDentist>>;

export type PublicDentistProfileResponse =
  ApiResponse<PublicSearchDentist>;

/* ======================================================
   DENTIST SEARCH SERVICE
====================================================== */

const dentistSearchService = {

  /**
   * Search publicly discoverable dentists linked
   * to active clinics.
   *
   * GET /booking/dentists
   *
   * query: Dentist name or specialization
   * location: Clinic city, state or postal code
   */
  async search(
    params: DentistSearchParams = {},
  ): Promise<DentistSearchResponse> {
    const response = await api.get<DentistSearchResponse>(
      '/booking/dentists',
      { params },
    );

    return response.data;
  },

  /**
   * Retrieve a publicly discoverable dentist
   * with active clinic associations.
   *
   * GET /booking/dentists/{id}
   */
  async getPublicById(
    id: number,
  ): Promise<PublicSearchDentist> {
    const response = await api.get<PublicDentistProfileResponse>(
      `/booking/dentists/${id}`,
    );

    return response.data.data;
  },
};

/* ======================================================
   EXPORT
====================================================== */

export default dentistSearchService;